package makedata;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


public class JsonIO {
public static class Result{
	ArrayList<Boolean> norepeat=new ArrayList<Boolean>();
	ArrayList<Integer> repeatid=new ArrayList<Integer>();
}
public static class newItem{
	String itemString;
	int newjsonid;
}
public static String JsonContext;
public static JSONArray JSONAdd=null;
public static int jsonsize=-1;
public static int jsonsizeing=-1;
static StringBuilder jsonallsb=new StringBuilder();

public String ReadFile(String Path){
BufferedReader reader = null;
String laststr = "";
try{
FileInputStream fileInputStream = new FileInputStream(Path);
InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
reader = new BufferedReader(inputStreamReader);
String tempString = null;
while((tempString = reader.readLine()) != null){
laststr += tempString;
}
reader.close();
}catch(IOException e){
e.printStackTrace();
}finally{
if(reader != null){
try {
reader.close();
} catch (IOException e) {
e.printStackTrace();
}
}
}
JsonContext=laststr;
return laststr;
}

public static JSONArray getElementArray(String JsonContext){
	JSONObject jsonObject=JSONObject.fromObject(JsonContext);
	JSONArray jsonAdd=JSONArray.fromObject(jsonObject.get("add"));
	
	return jsonAdd; 
}

public static JSONObject getOneDoc(JSONArray jsonAdd,int i){
	JSONObject jsonDoc=JSONObject.fromObject(jsonAdd.getString(i));
	JSONObject jsonDocContent=JSONObject.fromObject(jsonDoc.get("doc"));
	
	return jsonDocContent; 
}

/*public static Result checkRepeat(String label){
	boolean[] x={false};
	int[] m={-1};
	if(JSONAdd==null){
		JSONAdd = JsonIO.getElementArray(JsonContext);
	}
	if(jsonsize==-1){
		jsonsize=JSONAdd.size();
	}
	for(int i=0;i<(jsonsize-1);i++){
		JSONObject jsonDocContent=JsonIO.getOneDoc(JSONAdd,i);
		if(label.equalsIgnoreCase(jsonDocContent.getString("title"))){
			m[0]=jsonDocContent.getInt("id");
		}
	}
	if(m[0]>=0){
		x[0]=true;
	}
	
	Result result=new Result();
	result.repeatid=m;
	result.norepeat=x;
	return result; 
}
*/
public static Result checkRepeatArray(String[] newlabelarray){
	Result result=new Result();
	int arraylength=newlabelarray.length;
	if(JSONAdd==null){
		JSONAdd = JsonIO.getElementArray(JsonContext);
	}
	if(jsonsize==-1){
		jsonsize=JSONAdd.size();
	}
	
	
	int flag=0;
	int labellength=jsonsize;
	for(int j=0;j<arraylength;j++){
		//int labellength=jsonsize;
		for(int i=0;i<labellength;i++){
			//JSONObject jsonDocContent=JsonIO.getOneDoc(JSONAdd,i);
			JSONObject jsonDoc=JSONObject.fromObject(JSONAdd.getString(i));
			JSONObject jsonDocContent=JSONObject.fromObject(jsonDoc.get("doc"));
	
			
			//ystem.out.println(JSONAdd.toString());
			if(newlabelarray[j].equalsIgnoreCase(jsonDocContent.getString("title"))){
				//System.out.println(jsonDocContent.getString("title"));
			    //System.out.println(newlabelarray[j]);
				
				result.repeatid.add(jsonDocContent.getInt("id"));
				int ss=jsonDocContent.getInt("id");
				
				flag=1;
			}
			
		}
		if(flag==0){
			result.repeatid.add(-1);
	
			String jsonitem1=" {\"doc\" : {\"id\" : "+Integer.toString(++labellength)+",\n\"author\" : \"����\",\n\"title\" :\""+newlabelarray[j]+"\"\n}}" ;
			jsonArrayUpdate(jsonitem1);
			//++labellength;
		}
		else flag=0;
		if(result.repeatid.get(j)==-1){
			result.norepeat.add(true);
		}
		else{
			result.norepeat.add(false);
		}
	}
	
	

	
	return result; 
}

public static void initialize(){
	 JSONAdd = JsonIO.getElementArray(JsonContext);
	 jsonsize=JSONAdd.size();
}
public static int getNewId(){
	//System.out.println(JSONAdd.toString());
	
		jsonsize=JSONAdd.size();
	
	
	return jsonsize;
}

public static void jsonArrayUpdate(String newitem){
	JSONObject object = JSONObject.fromObject(newitem);
	JSONAdd.add(object);
   // System.out.println(JSONAdd);
}

public static newItem addJsonItem(String label,String jsonstring){
	newItem item=new newItem();
	if(jsonsizeing==-1)jsonsizeing=jsonsize;
	int i = ++jsonsize;
	
	String jsonitem="\n\"add\" : {\n\"doc\" : {\n\"id\" : "+Integer.toString(i)+",\n\"author\" : \"����\",\n\"title\" :\""+label+"\"\n}}," ;
	
    StringBuilder sb=new StringBuilder();
    jsonallsb.append(jsonitem);
	sb.append(jsonstring);
	long j=sb.indexOf("\"commit\"");
	sb.insert((int) j, jsonitem);
	//String sbstr=sb.toString().replaceAll("\"add\"", "\n\"add\"");
	item.itemString=sb.toString();
	item.newjsonid=i;
	return item;
}

public static void creatNewJsonFile(String sbstr,String filepath) throws IOException{
	
	    PrintWriter out = new PrintWriter(filepath,"UTF-8");
	    out.write(sbstr);
	    out.println();
	    //fw.close();
	    out.close();
	   }


public static String jsonNewLine(String json,String newjson) {
	newjson=json.replaceAll("\"add\"","\n\"add\"" );
    return newjson;
   }

}