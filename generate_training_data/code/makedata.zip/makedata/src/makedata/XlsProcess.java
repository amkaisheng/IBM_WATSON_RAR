package makedata;

import java.io.FileInputStream;   
  
import java.io.InputStream;   
  
    
  

import jxl.Cell;   
  
import jxl.Sheet;   
  
import jxl.Workbook;

public class XlsProcess {
	String Question_label;
	String Question;
	String Answer;
    Sheet readsheet = null;
	
	public Sheet setFile(String filename,int sheetnum)
	{
		jxl.Workbook readwb = null;
		 try    
		  
	        {   
			 InputStream instream = new FileInputStream(filename);     
		        readwb = Workbook.getWorkbook(instream);   
		        readsheet = readwb.getSheet(0);   
	        }
		 catch (Exception e) 
		 	{   
	            e.printStackTrace();   
		 	}
		return readsheet;
		
	}
	
	public String getLabel(int id)
	{
		Cell cell = readsheet.getCell(1, id);
		return cell.getContents();
	}
	
	public String getQuestion(int id)
	{
		Cell cell = readsheet.getCell(0, id);
		return cell.getContents();
	}
	
	public String[] getQuestion_Label(int id)
	{
		Cell cell1 = readsheet.getCell(0, id);
		Cell cell2 = readsheet.getCell(1, id);
		String[] str=new String[2];
		str[0]=cell1.getContents();
		str[1]=cell2.getContents();
		return str;
	}
	
	public String[] getAllLabel()
	{
		int rows=readsheet.getRows();
		String[] str=new String[rows];
		for (int i=0;i<rows;i++){
			Cell cell = readsheet.getCell(1, i);
			str[i]=(cell.getContents()).replaceAll("\n", "");
		}
		
		return str;
	}
	
	public String[] getAllQuestion()
	{
		int rows=readsheet.getRows();
		String[] str=new String[rows];
		for (int i=0;i<rows;i++){
			Cell cell = readsheet.getCell(0, i);
			str[i]=cell.getContents();
			str[i]=(cell.getContents()).replaceAll("\n", "");
		}
		
		return str;
	}
	
	public String[][] getAllQuestion_Label()
	{
		int rows=readsheet.getRows();
		String[][] str=new String[2][rows];
		for (int i=0;i<rows;i++){
			Cell cell1 = readsheet.getCell(0, i);
			Cell cell2 = readsheet.getCell(1, i);
			str[0][i]=(cell1.getContents()).replaceAll("\n", "");
			str[1][i]=(cell2.getContents()).replaceAll("\n", "");
		}
		
		return str;
	}
	
}
