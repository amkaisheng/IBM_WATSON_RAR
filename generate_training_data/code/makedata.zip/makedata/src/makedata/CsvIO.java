package makedata;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;



public class CsvIO {
public static ArrayList<String> readCsv(String csvFilePath) throws IOException{
	BufferedReader reader = null;
	ArrayList<String> ss=new ArrayList<String>();
	
	try{
	FileInputStream fileInputStream = new FileInputStream(csvFilePath);
	InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
	reader = new BufferedReader(inputStreamReader);
	String tempString = null;
	while((tempString = reader.readLine()) != null){
	ss.add(tempString);
	}
	reader.close();
	}catch(IOException e){
	e.printStackTrace();
	}finally{
	if(reader != null){
	try {
	reader.close();
	} catch (IOException e) {
	e.printStackTrace();
	}
	}
	}
	
	return ss;
	}





public static String[] combineCsvItem(String question,int jsonid)throws IOException{	
    String[] csvitem={question,Integer.toString(jsonid),"4"};
	return csvitem;
   
}

public static String combineCsvItem2string(String question,int jsonid)throws IOException{	
    String csvitem=question+","+Integer.toString(jsonid)+",4";
	return csvitem;
   
}

public static void writeCsvalldata(ArrayList<String> ss,String filepath) throws IOException{
	
	for(int i=0;i<ss.size();i++){
		PrintWriter out = new PrintWriter(filepath,"UTF-8");
	    out.write(ss.get(i));  
	    out.close();
		}
   
   }


public static void writeCsvoneline(String filepath,ArrayList<String> ss) throws IOException{
	OutputStreamWriter pw = null;
	pw = new OutputStreamWriter(new FileOutputStream(filepath),"UTF-8");
	BufferedWriter bw = new BufferedWriter(pw); 
	for(int i=0;i<ss.size();i++){
		if(i!=(ss.size()-1)){
			bw.write(ss.get(i));  
			bw.newLine();  
		}
		else{
			bw.write(ss.get(i));  
		}
		
		
}
	bw.close();  



}
}