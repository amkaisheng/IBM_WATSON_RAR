package makedata;

import java.io.File;   
import java.io.FileInputStream;   
  
import java.io.IOException;
import java.io.InputStream;   
  
    
  






import net.sf.json.JSONArray;
import jxl.Cell;   
  
import jxl.CellType;   
  
import jxl.Sheet;   
  
import jxl.Workbook;   
  
import jxl.write.Label;   
import makedata.XlsProcess;
  
    
  
public class test
  
{   
  
    public static void main(String[] args) throws IOException    
  
    {   
    
    	IntegratedProcess inpr=new IntegratedProcess();
    	inpr.process_Xls("C:/Users/Administrator/Desktop/second/MakeDataTestForVer1.1/label7.xls", "C:/Users/Administrator/Desktop/second/MakeDataTestForVer1.1/helpdeskfield.json","C:/Users/Administrator/Desktop/second/MakeDataTestForVer1.1/helpdesk_gt651.csv",1);
    	//inpr.process_Xls_oneitem("C:/Users/Administrator/Desktop/second/version1.1_815oneitemtest/helpdeskfield.json", "C:/Users/Administrator/Desktop/second/version1.1_815oneitemtest/helpdesk_gt651.csv", "new_question", "new_lable");
    	
    	
    	
    	
    }
  
        
  
}   