package test628;

import java.io.IOException;

import makedata.IntegratedProcess;

public class t628 {
	public static void main(String[] args) throws IOException    
	  
    {   
    
    	IntegratedProcess inpr=new IntegratedProcess();
    	inpr.process_Xls("C:/Users/Administrator/test628/lable3.xls", "C:/Users/Administrator/test628/helpdeskfield.json","C:/Users/Administrator/test628/helpdesk_gt6201.csv",167);
    	
    	
    }
}
